1.The first page for the customer is homepage.php which is inside the php folder.


2.The first page for admin is adminlogin.php which is inside the Admin folder.


3.Our website is made for zoom 100% size only.

 
