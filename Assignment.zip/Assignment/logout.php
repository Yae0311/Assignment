<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHPWebPage.php to edit this template
-->
<?php
session_start(); // start the session
// unset all session variables
$_SESSION = array();

// destroy the session
session_destroy();

// redirect the user to the login page
header("location: login.php");
exit;
?>